% part 1
p1_part1_dennis_silva;

% part 2
p1_part2_dennis_silva;