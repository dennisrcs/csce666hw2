% Running code for parts a, b and c
p4_parts_abc;

% Running code for parts d, e, f and g
p4_parts_defg;

% Running code for parts h, i, j and k
p4_parts_hijk;